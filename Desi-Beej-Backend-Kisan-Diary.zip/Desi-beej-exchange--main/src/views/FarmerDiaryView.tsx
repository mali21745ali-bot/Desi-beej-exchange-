import React, { useEffect, useState } from 'react';
import { BookOpen, Plus, Trash2, Sprout, CalendarDays, ArrowLeftRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { db, collection, query, where, onSnapshot, addDoc, deleteDoc, doc } from '../firebase';

type DiaryEntry = { id: string; date: string; crop: string; activity: string; notes: string; expense: string };
type ExchangeRecord = { id: string; seedTitle: string; quantity: string; unit: string; city: string; partnerName?: string; partnerCity?: string; partnerPhone?: string; completedAt: string };

export const FarmerDiaryView: React.FC = () => {
  const { userProfile, currentUser } = useAuth();
  const userId = currentUser?.uid || userProfile?.id || '';
  const [entries, setEntries] = useState<DiaryEntry[]>([]);
  const [exchangeRecords, setExchangeRecords] = useState<ExchangeRecord[]>([]);
  const [saving, setSaving] = useState(false);
  const [loadError, setLoadError] = useState('');
  useEffect(() => {
    if (!userId) { setEntries([]); return; }
    const diaryQuery = query(collection(db, 'farmer_diary'), where('ownerId', '==', userId));
    return onSnapshot(diaryQuery, snapshot => {
      const rows = snapshot.docs.map(item => ({ id: item.id, ...(item.data() as Omit<DiaryEntry, 'id'>) }));
      rows.sort((a, b) => b.date.localeCompare(a.date));
      setEntries(rows);
      setLoadError('');
    }, error => {
      console.error('Diary sync failed:', error);
      setLoadError('ڈائری لوڈ نہیں ہو سکی۔ Firebase کی سیکیورٹی رولز اور کنکشن چیک کریں۔');
    });
  }, [userId]);
  useEffect(() => {
    if (!userId) { setExchangeRecords([]); return; }
    const recordsQuery = query(collection(db, 'exchange_records'), where('ownerId', '==', userId));
    return onSnapshot(recordsQuery, snapshot => {
      const rows = snapshot.docs.map(item => ({ id: item.id, ...(item.data() as Omit<ExchangeRecord, 'id'>) }));
      rows.sort((a, b) => b.completedAt.localeCompare(a.completedAt));
      setExchangeRecords(rows);
    }, error => console.error('Exchange history sync failed:', error));
  }, [userId]);
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [crop, setCrop] = useState('');
  const [activity, setActivity] = useState('بیج بونا');
  const [notes, setNotes] = useState('');
  const [expense, setExpense] = useState('');

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userId || !crop.trim() || !notes.trim() || saving) return;
    setSaving(true);
    try {
      await addDoc(collection(db, 'farmer_diary'), {
        ownerId: userId, ownerName: userProfile?.name || '', date,
        crop: crop.trim(), activity, notes: notes.trim(), expense: expense.trim(),
        createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
      });
      setCrop(''); setNotes(''); setExpense(''); setLoadError('');
    } catch (error) {
      console.error('Diary save failed:', error);
      setLoadError('اندراج محفوظ نہیں ہوا۔ انٹرنیٹ اور Firebase اجازتیں چیک کریں۔');
    } finally { setSaving(false); }
  };
  const remove = async (id: string) => {
    try { await deleteDoc(doc(db, 'farmer_diary', id)); }
    catch (error) { console.error('Diary delete failed:', error); setLoadError('اندراج حذف نہیں ہو سکا۔'); }
  };

  if (!userProfile) return <div className="bg-white rounded-3xl p-8 text-center border border-stone-200"><BookOpen className="mx-auto mb-3 text-emerald-700"/><h2 className="font-bold text-xl">کسان ڈائری اور تبادلے کا ریکارڈ</h2><p className="text-stone-500 mt-2">اس فیچر کے لیے پہلے لاگ اِن کریں۔</p></div>;

  return <div className="space-y-6" dir="rtl">
    <header className="rounded-3xl bg-gradient-to-l from-emerald-900 to-emerald-700 text-white p-6 sm:p-8"><div className="flex items-center gap-3"><BookOpen className="w-9 h-9"/><div><h1 className="text-2xl font-extrabold">میری کسان ڈائری</h1><p className="text-emerald-100 text-sm mt-1">اپنی فصل، کھیت کے کام اور بیجوں کے تبادلے کا حساب محفوظ رکھیں۔</p></div></div></header>
    <section className="grid sm:grid-cols-3 gap-3">
      <div className="bg-white border rounded-2xl p-4"><div className="text-stone-500 text-sm">مکمل بیج تبادلے</div><div className="text-3xl font-black text-emerald-800 mt-1">{exchangeRecords.length}</div></div>
      <div className="bg-white border rounded-2xl p-4"><div className="text-stone-500 text-sm">ڈائری اندراجات</div><div className="text-3xl font-black text-emerald-800 mt-1">{entries.length}</div></div>
      <div className="bg-white border rounded-2xl p-4"><div className="text-stone-500 text-sm">کسان</div><div className="text-lg font-bold mt-2">{userProfile.name}</div><div className="text-xs text-stone-500">{userProfile.city}</div></div>
    </section>
    <section className="bg-white rounded-3xl border border-stone-200 p-5 sm:p-6 space-y-4">
      <h2 className="font-extrabold text-lg flex items-center gap-2"><Plus className="text-emerald-700"/> ڈائری میں نیا اندراج</h2>
      <form onSubmit={save} className="grid sm:grid-cols-2 gap-3">
        <label className="text-sm font-semibold">تاریخ<input type="date" value={date} onChange={e=>setDate(e.target.value)} className="mt-1 w-full rounded-xl border p-3"/></label>
        <label className="text-sm font-semibold">فصل کا نام<input value={crop} onChange={e=>setCrop(e.target.value)} placeholder="مثلاً گندم، کپاس، مکئی" className="mt-1 w-full rounded-xl border p-3" required/></label>
        <label className="text-sm font-semibold">کھیت کا کام<select value={activity} onChange={e=>setActivity(e.target.value)} className="mt-1 w-full rounded-xl border p-3">{['بیج بونا','آبپاشی','کھاد ڈالنا','گوڈی / جڑی بوٹی صفائی','سپرے','فصل کی کٹائی','زمین کی تیاری','دیگر'].map(x=><option key={x}>{x}</option>)}</select></label>
        <label className="text-sm font-semibold">خرچہ (روپے)<input value={expense} onChange={e=>setExpense(e.target.value)} type="number" min="0" placeholder="اختیاری" className="mt-1 w-full rounded-xl border p-3"/></label>
        <label className="text-sm font-semibold sm:col-span-2">تفصیل / نوٹس<textarea value={notes} onChange={e=>setNotes(e.target.value)} rows={3} placeholder="آج کھیت میں کیا کام کیا؟ موسم یا فصل کیسی رہی؟" className="mt-1 w-full rounded-xl border p-3" required/></label>
        <button disabled={saving} className="sm:col-span-2 bg-emerald-800 hover:bg-emerald-700 disabled:opacity-60 text-white rounded-xl py-3 font-bold">{saving ? 'محفوظ ہو رہا ہے…' : 'اندراج محفوظ کریں'}</button>
      </form>
      <p className="text-xs text-emerald-700">آپ کی ڈائری Firebase میں آپ کے اکاؤنٹ کے ساتھ محفوظ اور خودکار طور پر Sync ہوتی ہے۔</p>{loadError && <p role="alert" className="text-sm text-red-700">{loadError}</p>}
    </section>
    <section className="bg-white rounded-3xl border border-stone-200 p-5 space-y-4">
      <h2 className="font-extrabold text-lg flex items-center gap-2"><ArrowLeftRight className="text-emerald-700"/> میرے مکمل بیج تبادلے</h2>
      {exchangeRecords.length ? exchangeRecords.map(record=><div key={record.id} className="border rounded-2xl p-4 flex justify-between gap-3"><div><div className="font-bold">{record.seedTitle}</div><div className="text-sm text-stone-600">مقدار: {record.quantity} {record.unit} · {record.city}</div>{record.partnerName && <div className="text-sm text-stone-600">دوسرے کسان: {record.partnerName}{record.partnerCity ? ` · ${record.partnerCity}` : ''}</div>}{record.partnerPhone && <div className="text-sm text-stone-600">فون: {record.partnerPhone}</div>}<div className="text-xs text-emerald-700 mt-1">تبادلہ مکمل · {new Date(record.completedAt).toLocaleDateString('ur-PK')}</div></div><Sprout className="text-emerald-700 shrink-0"/></div>) : <p className="text-sm text-stone-500">ابھی آپ کے کسی تبادلے کو مکمل نشان زد نہیں کیا گیا۔ اپنے بیج کے اشتہار میں 'تبادلہ مکمل' کا بٹن دبائیں۔</p>}
    </section>
    <section className="bg-white rounded-3xl border border-stone-200 p-5 space-y-3"><h2 className="font-extrabold text-lg flex items-center gap-2"><CalendarDays className="text-emerald-700"/> ڈائری کی تاریخ وار تفصیل</h2>
      {entries.length ? entries.map(item=><article key={item.id} className="border rounded-2xl p-4"><div className="flex justify-between gap-3"><div><div className="font-bold">{item.crop} — {item.activity}</div><div className="text-xs text-stone-500 mt-1">{item.date}{item.expense ? ` · خرچہ: ${item.expense} روپے` : ''}</div></div><button onClick={()=>remove(item.id)} aria-label="حذف کریں" className="text-red-600 p-2"><Trash2 size={17}/></button></div><p className="text-sm mt-3 whitespace-pre-wrap">{item.notes}</p></article>) : <p className="text-sm text-stone-500">ابھی ڈائری خالی ہے۔ اپنا پہلا اندراج اوپر شامل کریں۔</p>}
    </section>
  </div>;
};
