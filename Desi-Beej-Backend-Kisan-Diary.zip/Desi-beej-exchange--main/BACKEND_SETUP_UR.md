# Desi Beej Exchange — Backend Setup (اردو)

## اس اپڈیٹ میں کیا شامل ہے؟
- کسان ڈائری کے اندراجات اب `farmer_diary` نامی Firestore collection میں محفوظ ہوتے ہیں۔
- ہر کسان صرف اپنے اکاؤنٹ کے ڈائری اندراجات دیکھ یا حذف کر سکتا ہے۔
- بیج کا مالک جب تبادلہ مکمل کرتا ہے تو `exchange_records` میں مستقل ریکارڈ بنتا ہے۔
- تبادلے کے وقت دوسرے کسان کا نام، شہر اور فون نمبر اختیاری طور پر درج کیا جا سکتا ہے۔
- کسان ڈائری میں مکمل تبادلوں کی فہرست دکھائی جاتی ہے۔

## Firebase میں ضروری قدم
1. Firebase Console کھولیں اور اسی Firebase project کو منتخب کریں جو `firebase-applet-config.json` میں استعمال ہو رہا ہے۔
2. Firestore Database کے **Rules** حصے میں اس ZIP کے `firestore.rules` کا مکمل مواد شائع کریں۔
3. Authentication میں وہی sign-in طریقہ فعال رکھیں جو ایپ میں استعمال ہو رہا ہے۔
4. ایپ کو build/deploy کریں۔ ڈائری اور تبادلے کے ریکارڈ کے لیے الگ collection پہلے سے بنانے کی ضرورت نہیں؛ پہلی کامیاب entry پر Firestore انہیں بنا دے گا۔

## اہم نوٹ
- اس پیکج میں frontend اور Firestore security rules کی تبدیلیاں شامل ہیں، لیکن Firebase Console پر rules خودکار طور پر publish نہیں کیے گئے۔
- Firebase project credentials یا آپ کے GitHub/Netlify اکاؤنٹ تک براہ راست رسائی کے بغیر live deployment نہیں کیا جا سکتا۔
- مکمل تبادلے کا ریکارڈ فی الحال اس کسان کے اکاؤنٹ میں محفوظ ہوتا ہے جو اپنے اشتہار کو "تبادلہ مکمل" کرتا ہے۔ دوسرے کسان کی شناختی تفصیل اختیاری ہے؛ دوسرے کسان کی الگ تصدیق/قبولیت کا مرحلہ آئندہ شامل کیا جا سکتا ہے۔
- اس ماحول میں dependency installation timeout ہونے کی وجہ سے production build مکمل verify نہیں ہو سکا۔ Deploy سے پہلے `npm install` اور `npm run build` چلائیں۔
